#include <stdio.h>
#include <stdlib.h>

int main()
{
    int luasSegitiga;
    int segitigaAlas;
    int tinggiSegitiga;


    luasSegitiga=segitigaAlas*tinggiSegitiga;
    printf("\nLuas Segitiga adalah : %d\n",luasSegitiga);
    return 0;
}
