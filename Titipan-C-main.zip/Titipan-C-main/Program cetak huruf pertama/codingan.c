#include <stdio.h>
#include <stdlib.h>

int main()
{
   int A,B,C;
   float R;
   printf("masukan bilangan A=");
   scanf("%d",&A);
   printf("masukan bilangan B=");
   scanf("%d",&B);
   C=A+B;
   R=(float)(A+B)/2;
   printf("%d + %d = %d\n",A,B,C);
   printf("Nilai Rata2 = %f",R);

   return 0;


//    int A,B,C;
    printf ("Masukan bilangan A=");
    scanf ("%d",&A);
    printf ("masukan bilangan B=");
    scanf ("%d",&B);
    C=A+B ;
    printf ("%d + %d=%d",A,B,C);
    return 0;

    printf ("*************************************\n");
    printf ("Nama Saya : Muhammad Raga Titipan   *\n");
    printf ("NIM : 1103194185                    *\n");
    printf ("Tanggal Lahir : 08 september 2000   *\n");
    printf ("Kelas : TK-43-04                    *\n");
    printf ("lumayan rada lieur wa euy           *\n");
    printf ("*************************************\n");

    return 0;
}
