#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i,suku,N;
    printf("berapa suku yang akan ditampilkan ?");
    scanf("%d",&N);
    for (i=1;i<=N;i++) {
    printf("%d ",suku);
    suku=suku+2;
    }
    return 0;
}
