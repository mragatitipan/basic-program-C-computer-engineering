#include <stdio.h>
#include <stdlib.h>

int main()
{
    int A,b=10,c;
    float X,Y=10.5;
    char ch1,ch2='a',str1[10],str2[10]="TelU";

    printf("masukan Nilai F\n");
    scanf("%f",&X);
    Y=X+Y;
    printf("X=%f Y=%f",X,Y);

}
