#include <stdio.h>
#include <stdlib.h>

int main()
{
   //Luas Persegi

    int sisi,luas;

    printf("\n Masukkan panjang sisi persegi : ");
    scanf("%d",&sisi);

    luas=sisi*sisi;

    printf("\n Luas persegi adalah %d \n",luas);
    return 0;
}
